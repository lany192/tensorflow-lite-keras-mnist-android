# TensorFlow Keras训练Mnist示例

## 模型的训练

运行python文件夹下的keras_mnist_tflite.py，生成H5模型文件，然后将h5模型转化成tflite模型，得到keras_mnist_model.tflite

## 使用模型

将训练生成的模型文件keras_mnist_model.tflite拷贝到assets文件夹，供android读取

